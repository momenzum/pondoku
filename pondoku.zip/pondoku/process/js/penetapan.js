 var cake_prices = new Array();
 cake_prices["Round6"]='1';
 cake_prices["Round8"]='2';
 cake_prices["Round9"]='3';
 	         
var benua = new Array();
benua["ASEAN"]='5';
benua["ASIA"]='10';
benua["DLL"]='15';


function Negara()
{
    var formNegara = document.forms["pibk"];
    var pilihNegara = formNegara.elements["negara"];
    asalNegara = benua[pilihNegara.value];
    return asalNegara;
}
         
function getCakeSizePrice()
{  
    var theForm = document.forms["pibk"];
    var selectedCake = theForm.elements["wn"];
    cakeSizePrice = cake_prices[selectedCake.value];
    return cakeSizePrice;
}

function Berat()
{
    var brt = document.pibk.berat.value;
    return brt;
    document.getElementById('update').innerHTML = brt;
}
function AddInputs()
{
    var kgs = document.pibk.berat.value;
    var kg;
    if (kgs <= 500)
    {
        kg = "1";
    }
    else if (kgs <= 1000)
    {
        kg = "2";
    }
    else if (kgs > 1000)
    {
        kg = "3";
    }
    return kg;
    
    document.getElementById('update').innerHTML = kg;
}
//Menghitung Penetapan
function Penetapan()
{
    var cakePrice = getCakeSizePrice() + AddInputs();
    var penetapan;
    if (cakePrice == 11)
    {
        penetapan = "0.3";
    }
    else if (cakePrice == 12)
    {
        penetapan = "0.25";
    }
    else if (cakePrice == 13)
    {
        penetapan = "0.2";
    }
    else if (cakePrice == 21)
    {
        penetapan = "1.75";
    }
    else if (cakePrice == 22)
    {
        penetapan = "1.25";
    }
    else if (cakePrice == 23)
    {
        penetapan = "0.9";
    } 
    else
    {
        penetapan = "1";
    }
    var divobj = document.getElementById('peneTapan');
    divobj.style.display='block';
    divobj.innerHTML = "<b>Penetapan = "+penetapan+"  USD/kg</b>";
    return penetapan;
    }

//menghitung FOB
function calculateTotal()   
{
    var total = Berat()*Penetapan();
    var ttl = total.toFixed(2);
    var divobj = document.getElementById('TotalPrice');
    divobj.style.display='block';
    divobj.innerHTML = "FOB = "+ttl;
    return ttl;
}

function Freight()   
{
    var costFreight = Negara()*calculateTotal()/100;
    var cFreight = costFreight.toFixed(2);
    var divobj = document.getElementById('negara_asal');
    divobj.style.display='block';
    divobj.innerHTML = "Freight = "+cFreight;
    return cFreight;
}

function Insurance()   
{
    var costInsurance = (parseInt(Freight())+parseInt(calculateTotal()))*5/1000;
    var asuransi = costInsurance.toFixed(2);
    var divobj = document.getElementById('insurance');
    divobj.style.display='block';
    divobj.innerHTML = "Insurance = "+asuransi;
    return asuransi;
}

function CIF()   
{
    var cif = parseFloat(Freight())+parseFloat(calculateTotal())+parseFloat(Insurance());
    var Cif = cif.toFixed(2);
    var divobj = document.getElementById('cif');
    divobj.style.display='block';
    divobj.innerHTML = "CIF = "+Cif;
    return Cif;
}

function NDPBM()
{
    var kurs = document.pibk.ndpbm.value;
    return kurs;
}

function NilaiPabean()   
{
    var np = Math.ceil(CIF()*NDPBM());
    var NP = np;
    var divobj = document.getElementById('np');
    divobj.style.display='block';
    divobj.innerHTML = "Nilai Pabean = "+NP;
    return NP;
}

function BM()   
{
    var beamasuk = Math.ceil(NilaiPabean()*35/100000);
    var bm = beamasuk*1000;
    var divobj = document.getElementById('bm');
    divobj.style.display='block';
    divobj.innerHTML = "Bea Masuk = "+bm;
    return bm;
}

function PPN()   
{
    var pajak = Math.ceil((parseFloat(NilaiPabean())+parseFloat(BM()))/10000);
    var ppn = pajak*1000;
    var divobj = document.getElementById('ppn');
    divobj.style.display='block';
    divobj.innerHTML = "PPN = "+ppn;
    return ppn;
}

function PPH()   
{
    var penghasilan = Math.ceil((parseFloat(NilaiPabean())+parseFloat(BM()))*7.5/100000);
    var pph = penghasilan*1000;
    var divobj = document.getElementById('pph');
    divobj.style.display='block';
    divobj.innerHTML = "PPh = "+pph;
    return pph;
}

function TOTAL()   
{

    var jumlah = parseFloat(BM()) + parseFloat(PPN()) + parseFloat(PPH());
    var jumlahtotal = jumlah.toLocaleString();
    var divobj = document.getElementById('total');
    divobj.style.display='block';
    divobj.innerHTML = "Total BM + PDRI = "+jumlahtotal;
    return jumlahtotal;
}

function hideTotal()
{
    var divobj = document.getElementById('totalPrice');
    divobj.style.display='none';
}



