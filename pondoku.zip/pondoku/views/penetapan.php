<div class="page-title">
  <div class="title">Penetapan</div>
  <div class="sub-title">Bea Masuk dan Pajak Dalam Rangka Impor PIBK</div>
</div>


<div data-ng-controller="advancedFormCtrl">
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-white m-b">
        <div class="card-header">
            <b>Estimasi Bea Masuk dan PDRI PIBK</b>
        </div>
        <div class="card-block" ui-jq="checkBo">
          <div class="row">
            


<div class="col-sm-6">
    <div id="wrap">
        <form action="" id="pibk" name="pibk">
        <div>
            <div class="cont_order">
               <fieldset>
                
               <h5><b>NDPBM (Kurs)</b></h5>
                <input type="text" id="ndpbm" value="13343" readonly/></br>
               </BR>
               <h5><b>Berat</b></h5>
               <input id="berat" name="berat" onkeyup="calculateTotal();Freight();Insurance();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" autocomplete="off" />
               <br/><br/>
               <h5><b>Warga Negara</b></h5>
                <label class="radiolabel"><input type="radio"  name="wn" value="Round6" onclick="calculateTotal();Freight();Insurance();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> WNI</label><br/>
                <label class="radiolabel"><input type="radio"  name="wn" value="Round8" onclick="calculateTotal();Freight();Insurance();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> WNA</label><br/>
                <label class="radiolabel"><input type="radio"  name="wn" value="Round9" onclick="calculateTotal();Freight();Insurance();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> KONSOLIDASI TKI</label><br/>
               <br/>
               <h5><b>Negara Asal</b></h5>
                <label class='radiolabel'><input type="radio"  name="negara" value="ASEAN" onclick="Freight();Insurance();calculateTotal();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> ASEAN</label><br/>
                <label class='radiolabel'><input type="radio"  name="negara" value="ASIA" onclick="Freight();Insurance();calculateTotal();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> ASIA</label><br/>
                <label class='radiolabel'><input type="radio"  name="negara" value="DLL" onclick="Freight();Insurance();calculateTotal();CIF();NilaiPabean();BM();PPN();PPH();TOTAL()" /> DLL</label><br/>
               <br/>
                       
        </div></fieldset>
            </div></div></form></div>
              <div class="col-sm-6">
                <div id="peneTapan"></div>
                <div id="TotalPrice"></div>
                <div id="negara_asal"></div>
                <div id="insurance"></div>
                <div id="cif"></div></br>
                <div id="np"></div></br>
                <div id="bm"></div>
                <div id="ppn"></div>
                <div id="pph"></div></br>
                <h5><b><span id="total"></span></b></h5>
              </div>
        </div>  
       </form>
        </div></div></div></div></div><!--End of wrap-->

