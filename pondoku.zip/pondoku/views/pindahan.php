<div class="m-t-n m-b">
  <div class="card m-b-0 bg-primary-dark p-a-md no-border m-b m-x-n-g">
    <div class="card-block" style="height: 200px">
    </div>
  </div>
  <div class="row post-header text-white">
    <div class="col p-b-lg col-xs-8 col-xs-offset-2">
      <h1>Impor Barang Pindahan</h1>
      <h4>A reference to things unseen</h4>
      <div class="meta">
        <span class="author">by <span class="author-name">Sean Carpenter</span></span>
        <span class="pub-date">Posted Dec. 25, 2015</span>
      </div>
    </div>
  </div>
    
<div class="page-title">
  <div class="title" translate="menu.TABS"></div>
  <ol class="breadcrumb no-bg pl0">
    <li>
      <a href="javascript:;">Home</a>
    </li>
    <li>
      <a href="javascript:;">UI Elements</a>
    </li>
    <li class="active ng-binding">Tabs and accordions</li>
  </ol>
</div>    
    
    
    
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-block p-a-0">
        <uib-tabset class="box-tab m-b-0">
          <uib-tab heading="Home">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras mattis consectetur purus sit amet fermentum. Nullam quis risus eget urna mollis ornare vel eu leo. Vestibulum id ligula porta felis euismod semper. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
          </uib-tab>
          <uib-tab heading="Profile">
            <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum. Etiam porta sem malesuada magna mollis euismod.</p>
          </uib-tab>
          <uib-tab heading="About">
            <p>Maecenas sed diam eget risus varius blandit sit amet non magna. Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
          </uib-tab>
          <uib-tab heading="Contacts">
            <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam quis risus eget urna mollis ornare vel eu leo. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna.</p>
          </uib-tab>
        </uib-tabset>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-block p-a-0">
        <uib-tabset class="box-tab m-b-0">
          <uib-tab heading="Home">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras mattis consectetur purus sit amet fermentum. Nullam quis risus eget urna mollis ornare vel eu leo. Vestibulum id ligula porta felis euismod semper. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
          </uib-tab>
          <uib-tab heading="Profile">
            <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum. Etiam porta sem malesuada magna mollis euismod.</p>
          </uib-tab>
          <uib-tab heading="About">
            <p>Maecenas sed diam eget risus varius blandit sit amet non magna. Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
          </uib-tab>
          <uib-tab heading="Contacts">
            <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam quis risus eget urna mollis ornare vel eu leo. Aenean lacinia bibendum nulla sed consectetur. Maecenas sed diam eget risus varius blandit sit amet non magna.</p>
          </uib-tab>
        </uib-tabset>
      </div>
    </div>
  </div>
</div>

    </div>
  </div>
</div>
